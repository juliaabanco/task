import React from "react";

const TaskDetails = () => {
  return <div>TaskDetails</div>;
};

export default TaskDetails;
